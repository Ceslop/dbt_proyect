-- created_at: 2026-03-24T07:21:02.760590400+00:00
-- finished_at: 2026-03-24T07:21:02.912891300+00:00
-- elapsed: 152ms
-- outcome: success
-- dialect: snowflake
-- node_id: not available
-- query_id: 01c33cb9-0001-a6f5-0002-35ca00015442
-- desc: list_relations_in_parallel
SHOW OBJECTS IN SCHEMA "DEV_OPERATIONAL_DATA"."RAW_OPERATIONAL_DATA" LIMIT 10000;
-- created_at: 2026-03-24T07:21:04.658965500+00:00
-- finished_at: 2026-03-24T07:21:04.744419400+00:00
-- elapsed: 85ms
-- outcome: error
-- error vendor code: 2003
-- error message: NotFound: [Snowflake] 002003 (42S02): SQL compilation error:
Table 'DEV_OPERATIONAL_DATA.RAW_OPERATIONAL_DATA.OP_OPERATIONAL_FCT_ORDERS_INCREMENTAL' does not exist or not authorized.
-- dialect: snowflake
-- node_id: not available
-- query_id: not available
-- desc: Get table schema
describe table "DEV_OPERATIONAL_DATA"."RAW_OPERATIONAL_DATA"."OP_OPERATIONAL_FCT_ORDERS_INCREMENTAL";
-- created_at: 2026-03-24T07:21:04.698490900+00:00
-- finished_at: 2026-03-24T07:21:04.768725300+00:00
-- elapsed: 70ms
-- outcome: error
-- error vendor code: 2003
-- error message: NotFound: [Snowflake] 002003 (42S02): SQL compilation error:
Table 'DEV_OPERATIONAL_DATA.RAW_OPERATIONAL_DATA.CUSTOMERS' does not exist or not authorized.
-- dialect: snowflake
-- node_id: not available
-- query_id: not available
-- desc: Get table schema
describe table "DEV_OPERATIONAL_DATA"."RAW_OPERATIONAL_DATA"."CUSTOMERS";
-- created_at: 2026-03-24T07:21:05.745280600+00:00
-- finished_at: 2026-03-24T07:21:05.822184800+00:00
-- elapsed: 76ms
-- outcome: error
-- error vendor code: 2003
-- error message: NotFound: [Snowflake] 002003 (42S02): SQL compilation error:
Table 'DEV_OPERATIONAL_DATA.RAW_OPERATIONAL_DATA.ORDERS' does not exist or not authorized.
-- dialect: snowflake
-- node_id: not available
-- query_id: not available
-- desc: Get table schema
describe table "DEV_OPERATIONAL_DATA"."RAW_OPERATIONAL_DATA"."ORDERS";
-- created_at: 2026-03-24T07:21:05.769772700+00:00
-- finished_at: 2026-03-24T07:21:05.852837+00:00
-- elapsed: 83ms
-- outcome: error
-- error vendor code: 2003
-- error message: NotFound: [Snowflake] 002003 (42S02): SQL compilation error:
Table 'DEV_OPERATIONAL_DATA.RAW_OPERATIONAL_DATA.SHIPMENT_EVENTS' does not exist or not authorized.
-- dialect: snowflake
-- node_id: not available
-- query_id: not available
-- desc: Get table schema
describe table "DEV_OPERATIONAL_DATA"."RAW_OPERATIONAL_DATA"."SHIPMENT_EVENTS";
