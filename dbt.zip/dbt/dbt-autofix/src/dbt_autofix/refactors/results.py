import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

from rich.console import Console
from ruamel.yaml.comments import CommentedMap

from dbt_autofix.refactors.fancy_quotes_utils import restore_fancy_quotes
from dbt_autofix.retrieve_schemas import SchemaSpecs
from dbt_autofix.semantic_definitions import SemanticDefinitions

console = Console()


@dataclass
class DbtDeprecationRefactor:
    log: str
    deprecation: Optional[str] = None

    def to_dict(self) -> dict:
        ret_dict = {"deprecation": self.deprecation, "log": self.log}

        return ret_dict


# ---------------------------------------------------------------------------
# Content dataclasses (constructed by apply_changeset, passed to changeset functions)
# ---------------------------------------------------------------------------


@dataclass
class YMLContent:
    original_str: str
    original_parsed: CommentedMap
    current_str: str


@dataclass
class SQLContent:
    original_str: str
    current_str: str
    current_file_path: Path


@dataclass
class PythonContent:
    original_str: str
    current_str: str
    current_file_path: Path


# ---------------------------------------------------------------------------
# Config dataclasses (built once per file batch, passed to each changeset)
# ---------------------------------------------------------------------------


@dataclass
class YMLRefactorConfig:
    schema_specs: SchemaSpecs
    semantic_definitions: Optional[SemanticDefinitions] = None


@dataclass
class DbtProjectYMLRefactorConfig:
    schema_specs: SchemaSpecs
    root_path: Path
    exclude_dbt_project_keys: bool = False


@dataclass
class SQLRefactorConfig:
    schema_specs: SchemaSpecs
    node_type: str


@dataclass
class PythonRefactorConfig:
    schema_specs: SchemaSpecs
    node_type: str


# ---------------------------------------------------------------------------
# Rule-level result dataclasses
# ---------------------------------------------------------------------------


@dataclass
class YMLRuleRefactorResult:
    rule_name: str
    refactored: bool
    refactored_yaml: str
    original_yaml: str
    deprecation_refactors: list[DbtDeprecationRefactor]

    @property
    def refactor_logs(self):
        return [refactor.log for refactor in self.deprecation_refactors]

    def to_dict(self) -> dict:
        ret_dict = {
            "deprecation_refactors": [
                deprecation_refactor.to_dict() for deprecation_refactor in self.deprecation_refactors
            ]
        }
        return ret_dict


@dataclass
class SQLRuleRefactorResult:
    rule_name: str
    refactored: bool
    refactored_content: str
    original_content: str
    deprecation_refactors: list[DbtDeprecationRefactor]
    refactored_file_path: Optional[Path] = None
    refactor_warnings: list[str] = field(default_factory=list)

    @property
    def refactor_logs(self):
        return [refactor.log for refactor in self.deprecation_refactors]

    def to_dict(self) -> dict:
        ret_dict = {
            "rule_name": self.rule_name,
            "deprecation_refactors": [refactor.to_dict() for refactor in self.deprecation_refactors],
        }
        return ret_dict


@dataclass
class PythonRuleRefactorResult:
    rule_name: str
    refactored: bool
    refactored_content: str
    original_content: str
    deprecation_refactors: list[DbtDeprecationRefactor]
    refactored_file_path: Optional[Path] = None
    refactor_warnings: list[str] = field(default_factory=list)

    @property
    def refactor_logs(self):
        return [refactor.log for refactor in self.deprecation_refactors]

    def to_dict(self) -> dict:
        ret_dict = {
            "rule_name": self.rule_name,
            "deprecation_refactors": [refactor.to_dict() for refactor in self.deprecation_refactors],
        }
        return ret_dict


# ---------------------------------------------------------------------------
# File-level result dataclasses
# ---------------------------------------------------------------------------


@dataclass
class YMLRefactorResult:
    dry_run: bool
    file_path: Path
    original_parsed: CommentedMap
    refactored_yaml: str
    original_yaml: str
    refactors: list[YMLRuleRefactorResult]

    @property
    def refactored(self) -> bool:
        return any(r.refactored for r in self.refactors)

    def apply_changeset(self, func: Callable, config: YMLRefactorConfig | DbtProjectYMLRefactorConfig) -> None:
        content = YMLContent(
            original_str=self.original_yaml,
            original_parsed=self.original_parsed,
            current_str=self.refactored_yaml,
        )
        result = func(content, config)
        if result.refactored:
            self.refactors.append(result)
            self.refactored_yaml = result.refactored_yaml

    def update_yaml_file(self) -> None:
        """Update the YAML file with the refactored content"""
        # Restore fancy quotes from placeholders before writing
        final_yaml = restore_fancy_quotes(self.refactored_yaml)
        Path(self.file_path).write_text(final_yaml)

    def print_to_console(self, json_output: bool = True):
        if not self.refactored:
            return

        if json_output:
            flattened_refactors = []
            for refactor in self.refactors:
                if refactor.refactored:
                    flattened_refactors.extend(refactor.to_dict()["deprecation_refactors"])

            to_print = {
                "mode": "dry_run" if self.dry_run else "applied",
                "file_path": str(self.file_path),
                "refactors": flattened_refactors,
            }
            print(json.dumps(to_print))
            return

        console.print(
            f"\n{'DRY RUN - NOT APPLIED: ' if self.dry_run else ''}Refactored {self.file_path}:",
            style="green",
        )
        for refactor in self.refactors:
            if refactor.refactored:
                console.print(f"  {refactor.rule_name}", style="yellow")
                for log in refactor.refactor_logs:
                    console.print(f"    {log}")


@dataclass
class SQLRefactorResult:
    dry_run: bool
    file_path: Path
    refactored_file_path: Path
    refactored_content: str
    original_content: str
    refactors: list[SQLRuleRefactorResult]
    has_warnings: bool = False

    @property
    def refactored(self) -> bool:
        return any(r.refactored for r in self.refactors) or (self.refactored_file_path != self.file_path)

    def apply_changeset(self, func: Callable, config: SQLRefactorConfig) -> None:
        content = SQLContent(
            original_str=self.original_content,
            current_str=self.refactored_content,
            current_file_path=self.refactored_file_path,
        )
        result = func(content, config)
        self.refactors.append(result)
        if result.refactored:
            self.refactored_content = result.refactored_content
            if result.refactored_file_path:
                self.refactored_file_path = result.refactored_file_path
        if result.refactor_warnings:
            self.has_warnings = True

    def update_sql_file(self) -> None:
        """Update the SQL file with the refactored content"""
        new_file_path = self.refactored_file_path or self.file_path
        if self.file_path != new_file_path:
            os.rename(self.file_path, self.refactored_file_path)

        Path(new_file_path).write_text(self.refactored_content)

    def print_to_console(self, json_output: bool = True):
        if not self.refactored and not self.has_warnings:
            return

        if json_output:
            flattened_refactors = []
            for refactor in self.refactors:
                if refactor.refactored:
                    flattened_refactors.extend(refactor.to_dict()["deprecation_refactors"])

            flattened_warnings = []
            for refactor in self.refactors:
                if refactor.refactor_warnings:
                    flattened_warnings.extend(refactor.refactor_warnings)

            to_print = {
                "mode": "dry_run" if self.dry_run else "applied",
                "file_path": str(self.file_path),
                "refactors": flattened_refactors,
                "warnings": flattened_warnings,
            }
            print(json.dumps(to_print))
            return

        console.print(
            f"\n{'DRY RUN - NOT APPLIED: ' if self.dry_run else ''}Refactored {self.file_path}:",
            style="green",
        )
        for refactor in self.refactors:
            if refactor.refactored:
                console.print(f"  {refactor.rule_name}", style="yellow")

                for log in refactor.refactor_logs:
                    console.print(f"    {log}")

                for warning in refactor.refactor_warnings:
                    console.print(f"    Warning: {warning}", style="red")
            elif refactor.refactor_warnings:
                console.print(f"  {refactor.rule_name}", style="yellow")
                for warning in refactor.refactor_warnings:
                    console.print(f"    Warning: {warning}", style="red")


@dataclass
class PythonRefactorResult:
    dry_run: bool
    file_path: Path
    refactored_file_path: Path
    refactored_content: str
    original_content: str
    refactors: list[PythonRuleRefactorResult]
    has_warnings: bool = False

    @property
    def refactored(self) -> bool:
        return any(r.refactored for r in self.refactors) or (self.refactored_file_path != self.file_path)

    def apply_changeset(self, func: Callable, config: PythonRefactorConfig) -> None:
        content = PythonContent(
            original_str=self.original_content,
            current_str=self.refactored_content,
            current_file_path=self.refactored_file_path,
        )
        result = func(content, config)
        self.refactors.append(result)
        if result.refactored:
            self.refactored_content = result.refactored_content
            if result.refactored_file_path:
                self.refactored_file_path = result.refactored_file_path
        if result.refactor_warnings:
            self.has_warnings = True

    def update_python_file(self) -> None:
        """Update the Python file with the refactored content"""
        new_file_path = self.refactored_file_path or self.file_path
        if self.file_path != new_file_path:
            os.rename(self.file_path, self.refactored_file_path)

        Path(new_file_path).write_text(self.refactored_content)

    def print_to_console(self, json_output: bool = True):
        if not self.refactored and not self.has_warnings:
            return

        if json_output:
            flattened_refactors = []
            for refactor in self.refactors:
                if refactor.refactored:
                    flattened_refactors.extend(refactor.to_dict()["deprecation_refactors"])

            flattened_warnings = []
            for refactor in self.refactors:
                if refactor.refactor_warnings:
                    flattened_warnings.extend(refactor.refactor_warnings)

            to_print = {
                "mode": "dry_run" if self.dry_run else "applied",
                "file_path": str(self.file_path),
                "refactors": flattened_refactors,
                "warnings": flattened_warnings,
            }
            print(json.dumps(to_print))
            return

        console.print(
            f"\n{'DRY RUN - NOT APPLIED: ' if self.dry_run else ''}Refactored {self.file_path}:",
            style="green",
        )
        for refactor in self.refactors:
            if refactor.refactored:
                console.print(f"  {refactor.rule_name}", style="yellow")

                for log in refactor.refactor_logs:
                    console.print(f"    {log}")

                for warning in refactor.refactor_warnings:
                    console.print(f"    Warning: {warning}", style="red")
            elif refactor.refactor_warnings:
                console.print(f"  {refactor.rule_name}", style="yellow")
                for warning in refactor.refactor_warnings:
                    console.print(f"    Warning: {warning}", style="red")
